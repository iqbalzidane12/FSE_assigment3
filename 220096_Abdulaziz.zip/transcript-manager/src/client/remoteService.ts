import axios, { AxiosResponse } from 'axios';

// all references to axios are localized here

const inputPort = process.env.PORT || 4001;
let axiosClient = axios.create({ baseURL: `http://localhost:${inputPort}` });

export function setBaseURL(baseURL: string) {
  axiosClient = axios.create({ baseURL: baseURL });
}

// converts a failed request into an Error that exposes both the HTTP status code
// and the message sent by the server (e.g. "No student name specified"),
// so that callers and tests can tell *why* a request was rejected.
function toRemoteError(e: unknown): Error {
  if (axios.isAxiosError(e) && e.response) {
    const { status, data } = e.response;
    const body = typeof data === 'string' ? data : JSON.stringify(data);
    return new Error(`Request failed with status code ${status}: ${body}`);
  }
  return new Error(String(e));
}

export async function remoteGet<T>(path: string): Promise<T> {
  try {
    const response: AxiosResponse<T> = await axiosClient.get(path);
    return response.data;
  } catch (e) {
    throw toRemoteError(e);
  }
}

export async function remoteDelete<T>(path: string): Promise<T> {
  try {
    const response: AxiosResponse<T> = await axiosClient.delete(path);
    return response.data;
  } catch (e) {
    throw toRemoteError(e);
  }
}

export async function remotePost<T>(path: string, data?: object): Promise<T> {
  try {
    const response: AxiosResponse<T> = await axiosClient.post(path, data);
    return response.data;
  } catch (e) {
    throw toRemoteError(e);
  }
}
