import * as db from './transcriptManager';
import { addStudent, StudentID } from './transcriptManager';

/**
 * Unit tests for the data layer (transcriptManager.ts).
 *
 * These tests call the exported functions directly: there is no HTTP server and no network.
 * Every test starts from a freshly initialized database (see beforeEach), so the tests are
 * hermetic and independent of the order in which they run.
 *
 * Note: initialize() seeds the database with 4 dummy students (Sardor, Jasur, Jasur, Nigora).
 * The tests below therefore use names that are NOT part of the seed data ('Aziza', 'Bekzod'),
 * which lets getStudentIDs(name) return exactly the students created inside the test.
 */

// An ID that can never exist: IDs are handed out sequentially starting at 1.
const MISSING_ID: StudentID = 999999;

// Reset the database to its known initial state before every single test.
beforeEach(() => {
  db.initialize();
});

describe('Testing addStudent() method', () => {
  it('should create 4 dummy students when you call initialize()', () => {
    let transcripts = db.getAll();
    expect(transcripts.length).toBe(4);
  });

  it('should check valid inputs for addStudent()', () => {
    let length = db.getAll().length;
    let id = addStudent('Li');
    expect(typeof id).toBe('number');
    expect(id).toBeGreaterThanOrEqual(length);
  });

  it('should check invalid inputs for addStudent()', () => {
    // addStudent() only documents (and enforces) two rules: the name can be neither
    // null nor empty. Any other name is accepted, e.g. a one-letter name or a name with digits.
    expect(() => addStudent(null)).toThrow("Name can't be null");
    expect(() => addStudent('')).toThrow("Name can't be empty");
  });

  it('should not store anything when addStudent() rejects its input', () => {
    // Given: a database with the 4 seed students
    // When: invalid names are rejected
    expect(() => addStudent('')).toThrow();
    expect(() => addStudent(null)).toThrow();
    // Then: the database is unchanged
    expect(db.getAll()).toHaveLength(4);
  });

  it('should return a numeric ID and store the student', () => {
    // Given: a freshly initialized database
    // When: a student is added
    const id: StudentID = db.addStudent('Aziza');

    // Then: the ID is a positive number and the student can be found by name
    expect(typeof id).toBe('number');
    expect(id).toBeGreaterThan(0);
    expect(db.getStudentIDs('Aziza')).toContain(id);

    // And: the new student starts with an empty list of grades
    expect(db.getTranscript(id)).toEqual({
      student: { studentID: id, studentName: 'Aziza' },
      grades: [],
    });
  });

  it('should give different IDs to different students, even with the same name', () => {
    // Given: two students that share the same name
    const firstID = db.addStudent('Aziza');
    const secondID = db.addStudent('Aziza');

    // Then: the IDs differ, and both students are found under that name
    expect(secondID).not.toBe(firstID);
    const ids = db.getStudentIDs('Aziza');
    expect(ids).toHaveLength(2);
    expect(ids).toContain(firstID);
    expect(ids).toContain(secondID);
  });
});

describe('Testing getTranscript() method', () => {
  it('should return undefined for a missing ID', () => {
    expect(db.getTranscript(MISSING_ID)).toBeUndefined();
  });

  it('should return the transcript of an existing student', () => {
    const id = db.addStudent('Aziza');
    const transcript = db.getTranscript(id);
    expect(transcript).toBeDefined();
    expect(transcript.student.studentID).toBe(id);
    expect(transcript.student.studentName).toBe('Aziza');
  });
});

describe('Testing deleteStudent() method', () => {
  it('should remove only the requested student', () => {
    // Given: two students with different names
    const azizaID = db.addStudent('Aziza');
    const bekzodID = db.addStudent('Bekzod');

    // When: one of them is deleted
    db.deleteStudent(azizaID);

    // Then: only the other one is left (the 4 seed students are untouched as well)
    expect(db.getStudentIDs('Aziza')).toEqual([]);
    expect(db.getStudentIDs('Bekzod')).toEqual([bekzodID]);
    expect(db.getTranscript(azizaID)).toBeUndefined();
    expect(db.getAll()).toHaveLength(4 + 1);
  });

  it('should throw when the student does not exist', () => {
    // A completely unknown ID
    expect(() => db.deleteStudent(MISSING_ID)).toThrow(`no student with ID = ${MISSING_ID}`);
  });

  it('should throw when the same student is deleted twice', () => {
    const id = db.addStudent('Aziza');
    db.deleteStudent(id);
    expect(() => db.deleteStudent(id)).toThrow(`no student with ID = ${id}`);
  });
});

describe('Testing addGrade() method', () => {
  it('should add grades for different courses to a student', () => {
    // Given: one student
    const id = db.addStudent('Aziza');

    // When: grades for two different courses are added, Then: neither call throws
    expect(() => db.addGrade(id, 'CS360', 95)).not.toThrow();
    expect(() => db.addGrade(id, 'CS411', 85)).not.toThrow();

    // And: both grades are stored in the transcript
    expect(db.getTranscript(id).grades).toEqual([
      { course: 'CS360', grade: 95 },
      { course: 'CS411', grade: 85 },
    ]);
  });

  it('should reject a second grade for the same course and keep the original grade', () => {
    // Given: a student who already has a grade in CS360
    const id = db.addStudent('Aziza');
    db.addGrade(id, 'CS360', 95);

    // When/Then: adding another CS360 grade is rejected
    expect(() => db.addGrade(id, 'CS360', 90)).toThrow(
      `student ${id} already has a grade in course CS360`,
    );

    // And: the original grade was not overwritten and no duplicate was stored
    expect(db.getGrade(id, 'CS360')).toBe(95);
    expect(db.getTranscript(id).grades).toHaveLength(1);
  });

  it('should throw when the student does not exist', () => {
    expect(() => db.addGrade(MISSING_ID, 'CS360', 95)).toThrow(`no student with ID = ${MISSING_ID}`);
  });
});

describe('Testing getGrade() method', () => {
  it('should return the grade of the student as a number', () => {
    // Given: a student with a grade in CS360
    const id = db.addStudent('Aziza');
    db.addGrade(id, 'CS360', 95);

    // When: the grade is fetched
    const grade = db.getGrade(id, 'CS360');

    // Then: it is the exact numeric grade that was stored
    expect(typeof grade).toBe('number');
    expect(grade).toBe(95);
  });

  it('should return the right grade when the student has several courses', () => {
    const id = db.addStudent('Aziza');
    db.addGrade(id, 'CS360', 95);
    db.addGrade(id, 'CS411', 85);
    expect(db.getGrade(id, 'CS411')).toBe(85);
    expect(db.getGrade(id, 'CS360')).toBe(95);
  });

  it('should throw when the student has no grade in the course', () => {
    const id = db.addStudent('Aziza');
    expect(() => db.getGrade(id, 'CS360')).toThrow(`no grade for student ${id} in course CS360`);
  });

  it('should throw when the student does not exist', () => {
    // Only the fact that it throws is asserted: the current implementation fails with a generic
    // TypeError for unknown students, and the exact message is not a contract worth pinning down.
    expect(() => db.getGrade(MISSING_ID, 'CS360')).toThrow();
  });
});
