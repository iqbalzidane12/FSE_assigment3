import * as client from './client/client';
import axios from 'axios';
import Express from 'express';
import * as http from 'http';
import transcriptServer from './server/transcriptServer';
import { AddressInfo } from 'net';
import { setBaseURL } from './client/remoteService';
import * as db from './server/transcriptManager';

// An ID that can never exist: IDs are handed out sequentially starting at 1.
const MISSING_ID = 999999;

/**
 * Tests for the Transcript Manager. This test suite automatically deploys a local testing server
 * and cleans it up when it's done. Each test is hermetic, as the datastore is cleared before each
 * test runs.
 *
 * The tests talk to the server through the client functions in src/client/client.ts. The client
 * hides HTTP status codes of successful responses (e.g. 201 or 204), so a few tests additionally
 * send a raw HTTP request via axios to check those status codes directly.
 *
 * Note: initialize() seeds the datastore with 4 students (Sardor, Jasur, Jasur, Nigora). The tests
 * use other names ('Aziza', 'Bekzod') so that name lookups return only students created by the test.
 */
describe('TranscriptManager', () => {
  // The server instance, once deployed for testing purposes
  let server: http.Server;
  // The address of the testing server, used for raw HTTP requests
  let baseURL: string;

  // Set up the server once before all tests run
  beforeAll(async () => {
    // Deploy a testing server
    const app = Express();
    server = http.createServer(app);

    // Add the transcript server's routes to the express server
    transcriptServer(app);

    db.initialize();

    // Start the server on a random, free port (port 0) and wait until it is really listening.
    await new Promise<void>(resolve => server.listen(0, resolve));

    // Fetch that address and configure the client to use that server.
    const address = server.address() as AddressInfo;
    baseURL = `http://localhost:${address.port}`;
    setBaseURL(baseURL);
  });

  // Tear down the server once all tests are done
  afterAll(async () => {
    // After all tests are done, shut down the server to avoid any resource leaks
    await new Promise<void>((resolve, reject) =>
      server.close(error => (error ? reject(error) : resolve())),
    );
  });

  // Clear the datastore before each test to ensure hermetic tests
  beforeEach(() => {
    // Before any test runs, clean up the datastore. This should ensure that tests are hermetic.
    db.initialize();

    // The server logs every rejected request (console.trace) and dumps all transcripts
    // (console.log). That is expected here and would only bury the test results, so mute it.
    jest.spyOn(console, 'trace').mockImplementation(() => {});
    jest.spyOn(console, 'log').mockImplementation(() => {});
  });

  // Put the real console functions back after each test
  afterEach(() => {
    jest.restoreAllMocks();
  });

  // Unit tests - create a student
  describe('Unit tests: creating students', () => {
    it('should return an ID', async () => {
      const createdStudent = await client.addStudent('Aziza');
      expect(createdStudent.studentID).toBeGreaterThan(4);
    });

    it('should return different IDs for different students', async () => {
      // Given: two students with different names
      const aziza = await client.addStudent('Aziza');
      const bekzod = await client.addStudent('Bekzod');

      // Then: each gets its own ID
      expect(bekzod.studentID).not.toBe(aziza.studentID);
    });
  });

  // Unit tests - post a grade
  describe('Unit tests: posting grades', () => {
    it('should not accept grades for invalid student IDs', async () => {
      await expect(client.addGrade(9999, 'CS360', 95)).rejects.toThrow();
    });

    it('should accept grades for students ', async () => {
      // Given: a new student
      const { studentID } = await client.addStudent('Aziza');

      // When/Then: posting a grade succeeds, and the grade can be read back
      await expect(client.addGrade(studentID, 'CS360', 95)).resolves.not.toThrow();
      expect(await client.getGrade(studentID, 'CS360')).toMatchObject({ grade: 95 });
    });
  });

  // POST /transcripts
  describe('POST /transcripts', () => {
    it('should return 201 and an ID for a valid name', async () => {
      // When: a student is created through the client
      const created = await client.addStudent('Aziza');

      // Then: the response holds a positive numeric ID ...
      expect(typeof created.studentID).toBe('number');
      expect(created.studentID).toBeGreaterThan(0);
      // ... and the student can be found by name afterwards
      expect(await client.getStudentIDs('Aziza')).toContain(created.studentID);
    });

    it('should answer with the HTTP status 201 (Created)', async () => {
      // The client hides the status of successful responses, so send a raw request.
      const response = await axios.post(`${baseURL}/transcripts`, { name: 'Aziza' });
      expect(response.status).toBe(201);
      expect(response.data.studentID).toBeGreaterThan(0);
    });

    it('should return 400 when the name is empty', async () => {
      // The client surfaces the server's 400 error as a rejected promise
      await expect(client.addStudent('')).rejects.toThrow(/400/);
      await expect(client.addStudent('')).rejects.toThrow('No student name specified');
    });

    it('should return 400 when the name is missing', async () => {
      // The client always sends a name, so send a raw request with an empty body.
      // validateStatus makes axios return error statuses instead of throwing.
      const response = await axios.post(`${baseURL}/transcripts`, {}, { validateStatus: () => true });
      expect(response.status).toBe(400);
      expect(response.data).toBe('No student name specified');
    });

    it('should not create a student when the request is rejected', async () => {
      await expect(client.addStudent('')).rejects.toThrow();
      // Only the 4 seed students exist
      expect(await client.getAllTranscripts()).toHaveLength(4);
    });
  });

  // GET /transcripts/:id
  describe('GET /transcripts/:id', () => {
    it('should return 200 and the transcript for a valid ID', async () => {
      // Given: a new student
      const { studentID } = await client.addStudent('Aziza');

      // When: the transcript is fetched by ID
      const transcript = await client.getTranscript(studentID);

      // Then: it describes this student and has no grades yet
      expect(transcript).toEqual({
        student: { studentID, studentName: 'Aziza' },
        grades: [],
      });
    });

    it('should return 404 for a missing ID', async () => {
      // The client surfaces the 404 as a rejected promise
      await expect(client.getTranscript(MISSING_ID)).rejects.toThrow(/404/);
    });
  });

  // GET /studentids?name=...
  describe('GET /studentids?name=...', () => {
    it('should return all IDs for the name', async () => {
      // Given: two students with the same name and one with a different name
      const first = await client.addStudent('Aziza');
      const second = await client.addStudent('Aziza');
      const other = await client.addStudent('Bekzod');

      // When: the IDs are fetched by name
      const ids = await client.getStudentIDs('Aziza');

      // Then: exactly the two matching students are listed
      expect(ids).toHaveLength(2);
      expect(ids).toContain(first.studentID);
      expect(ids).toContain(second.studentID);
      expect(ids).not.toContain(other.studentID);
    });

    it('should return an empty list when no student has the name', async () => {
      expect(await client.getStudentIDs('Nobody')).toEqual([]);
    });
  });

  // DELETE /transcripts/:id
  describe('DELETE /transcripts/:id', () => {
    it('should actually delete the student', async () => {
      // Given: two students, so we can also check that only one of them is deleted
      const aziza = await client.addStudent('Aziza');
      const bekzod = await client.addStudent('Bekzod');

      // When: the first one is deleted
      await client.deleteStudent(aziza.studentID);

      // Then: it is no longer listed, and fetching it by ID fails with a 404 ...
      expect(await client.getStudentIDs('Aziza')).not.toContain(aziza.studentID);
      await expect(client.getTranscript(aziza.studentID)).rejects.toThrow(/404/);
      // ... while the other student is still there
      expect(await client.getStudentIDs('Bekzod')).toContain(bekzod.studentID);
    });

    it('should answer with the HTTP status 204 (No Content)', async () => {
      const { studentID } = await client.addStudent('Aziza');
      const response = await axios.delete(`${baseURL}/transcripts/${studentID}`);
      expect(response.status).toBe(204);
    });

    it('should return 404 when the student does not exist', async () => {
      await expect(client.deleteStudent(MISSING_ID)).rejects.toThrow(/404/);
    });
  });

  // POST /transcripts/:studentID/:course
  describe('POST /transcripts/:studentID/:course', () => {
    it('should return 201 when a grade is added', async () => {
      const { studentID } = await client.addStudent('Aziza');

      // Through the client: the call succeeds ...
      await expect(client.addGrade(studentID, 'CS360', 95)).resolves.not.toThrow();

      // ... and with a raw request we can check the status code itself
      const response = await axios.post(`${baseURL}/transcripts/${studentID}/CS411`, { grade: 85 });
      expect(response.status).toBe(201);
    });

    it('should return 400 for a duplicate course and keep the original grade', async () => {
      // Given: a student who already has a grade in CS360
      const { studentID } = await client.addStudent('Aziza');
      await client.addGrade(studentID, 'CS360', 95);

      // When/Then: adding another grade for the same course is rejected with a 400 ...
      await expect(client.addGrade(studentID, 'CS360', 90)).rejects.toThrow(/400/);

      // ... and the original grade is untouched
      expect(await client.getGrade(studentID, 'CS360')).toMatchObject({ grade: 95 });
    });

    it('should return 400 for an invalid grade', async () => {
      const { studentID } = await client.addStudent('Aziza');

      // An empty string and a non-numeric string are not valid grades. The casts are needed
      // because the client's TypeScript signature only allows numbers.
      await expect(client.addGrade(studentID, 'CS360', '' as unknown as number)).rejects.toThrow(
        /400/,
      );
      await expect(
        client.addGrade(studentID, 'CS360', 'abc' as unknown as number),
      ).rejects.toThrow(/Invalid grade/);

      // No grade was stored by the rejected requests
      expect((await client.getTranscript(studentID)).grades).toEqual([]);
    });

    it('should return 400 when the student does not exist', async () => {
      await expect(client.addGrade(MISSING_ID, 'CS360', 95)).rejects.toThrow(/400/);
    });
  });

  // GET /transcripts/:studentID/:course
  describe('GET /transcripts/:studentID/:course', () => {
    it('should return the grade object { studentID, course, grade }', async () => {
      // Given: a student with a grade in CS360
      const { studentID } = await client.addStudent('Aziza');
      await client.addGrade(studentID, 'CS360', 95);

      // When/Then: the response has exactly the documented shape and values
      expect(await client.getGrade(studentID, 'CS360')).toEqual({
        studentID,
        course: 'CS360',
        grade: 95,
      });
    });

    it('should fail when the student has no grade in the course', async () => {
      const { studentID } = await client.addStudent('Aziza');
      await expect(client.getGrade(studentID, 'CS360')).rejects.toThrow(/400/);
    });
  });
});
